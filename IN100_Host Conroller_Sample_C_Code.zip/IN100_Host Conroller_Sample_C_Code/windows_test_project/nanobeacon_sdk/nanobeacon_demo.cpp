﻿#include <iostream>
#include <cstdio>
#include <Windows.h>
#include "serial_if.h"
#include "nano_bcn_api.h"

extern "C" void host_sleep(uint32_t ms)
{
    Sleep(ms);
}

extern "C" int host_write(uint8_t * buf, uint16_t buf_len, uint32_t tmo)
{
    int res;
    res = serial_write(buf, buf_len);
    if (res == SERIAL_ERR_NO_ERROR)
        res = UART_ERR_NO_ERROR;
    else if (res == SERIAL_ERR_WRITE_TMO)
        res = UART_ERR_TMO;

    return res;
}


extern "C" int host_read(uint8_t * buf, uint16_t buf_len, uint32_t tmo)
{
    int res;
    res = serial_read(buf, buf_len, tmo);
    if (res == SERIAL_ERR_NO_ERROR)
        res = UART_ERR_NO_ERROR;
    else if (res == SERIAL_ERR_WRITE_TMO)
        res = UART_ERR_TMO;

    return res;
}

extern "C" void host_uart_break(int on)
{
    serial_break(on);
}

extern "C" void print_data(uint16_t data)
{
    printf("%04x \n", data);
}

static uint8_t binary[512];


int main()
{
    host_itf_t hif;
    uint16_t efuse_val;
    uint16_t efuse_val2;
    uint16_t efuse_val3;
    uint8_t bdaddr[6] = { 0x10, 0x02, 0x03, 0x04, 0x05, 0x06 };
    uint8_t adv_raw[] = {0x05, 0xff, 0x05, 0x05, 0x01, 0x02 };
    uint8_t adv_raw2[] = { 0x07, 0xff, 0x05, 0x05, 0x01, 0x02, 0x03, 04 };
    int j = 0;
    const char* port = "\\\\.\\COM4";
    int res = serial_open(port, 115200);
    if (res != SERIAL_ERR_NO_ERROR) {
        std::cout << "uart open failed ! " << port << std::endl;
        return 0;
    }
    hif.delay = host_sleep;
    hif.serial_rx = host_read;
    hif.serial_tx = host_write;
    hif.serial_break = host_uart_break;

    res = nano_bcn_init(&hif);
    std::cout << "nano_bcn_init:" << res << std::endl;

    res = nano_bcn_chip_reset();
    std::cout << "nano_bcn_chip_reset:" << res << std::endl;

    res = nano_bcn_board_setup(11, 0);
    std::cout << "nano_bcn_board_setup:" << res << std::endl;
    int example = 3;
    switch (example)
    {
    case 0:
        /*disable on-chip measurement VCC and temperature*/
        bcn_on_chip_measurement_en(0, 0);

        /*advertising set #1 , advertising on channels 37,38,39, period is 1000ms*/
        bcn_adv_tx_set(ADV_SET_1, 1000, ADV_CH_37_38_39, ADV_MODE_CONTINUOUS);
        bcn_adv_address_set(ADV_SET_1, ADDR_PUBLIC, bdaddr, 60, 0);

        adv_raw[0] = 9;
        /*add predefined data to advertising payload */
        bcn_adv_data_add_predefined_data(ADV_SET_1, adv_raw, sizeof(adv_raw), 0);

        /* add advertising count data to advertising payload */
        bcn_adv_data_add_adv_count(ADV_SET_1, 4, 0, 0);
        break;
    case 1:
        /*enable on-chip measurement VCC and temperature*/
        bcn_on_chip_measurement_en(1, 1);
        efuse_val = 0;
        res = nano_bcn_read_efuse(0x09, &efuse_val);
        if (0 != res) {
            std::cout << "efuse read failed" << std::endl;
            return 0;
        }

        /*Calibration adn unit mapping processing*/
        bcn_on_chip_measurement_temp_unit_mapping(efuse_val, 0.01);
        efuse_val = 0;
        nano_bcn_read_efuse(0x06, &efuse_val);
        efuse_val2 = 0;
        nano_bcn_read_efuse(0x07, &efuse_val2);
        efuse_val3 = 0;
        nano_bcn_read_efuse(0x08, &efuse_val3);
        bcn_on_chip_measurement_vcc_unit_mapping(efuse_val, efuse_val2, efuse_val3, 0.03125);

        adv_raw[0] = 8;
        /*advertising set #1 , advertising on channels 37,38,39, period is 1000ms*/
        bcn_adv_tx_set(ADV_SET_1, 1000, ADV_CH_37_38_39, ADV_MODE_CONTINUOUS);
        bcn_adv_address_set(ADV_SET_1, ADDR_PUBLIC, bdaddr, 60, 0);

        /*add predefined data to advertising payload */
        bcn_adv_data_add_predefined_data(ADV_SET_1, adv_raw, sizeof(adv_raw), 0);

        /*add VCC data to advertising payload */
        bcn_adv_data_add_vcc(ADV_SET_1, 1, 0, 0);

        /*add temperature data to advertising payload */
        bcn_adv_data_add_temperature(ADV_SET_1, 2, 0, 0);
        break;
    case 2:
        bcn_on_chip_measurement_en(0, 0);

        /* advertising set #1 */
        bcn_adv_tx_set(ADV_SET_1, 1000, ADV_CH_37_38_39, ADV_MODE_CONTINUOUS);
        bcn_adv_address_set(ADV_SET_1, ADDR_PUBLIC, bdaddr, 60, 0);
        bcn_adv_data_add_predefined_data(ADV_SET_1, adv_raw, sizeof(adv_raw), 0);

        /* advertising set #2 */
        bcn_adv_tx_set(ADV_SET_2, 1000, ADV_CH_37_38_39, ADV_MODE_CONTINUOUS);
        bdaddr[0] = 0x11;
        bcn_adv_address_set(ADV_SET_2, ADDR_PUBLIC, bdaddr, 60, 0);
        bcn_adv_data_add_predefined_data(ADV_SET_2, adv_raw2, sizeof(adv_raw2), 0);
        break;
    default:
        bcn_on_chip_measurement_en(0, 0);
        nano_bcn_set_advertising(bdaddr, 1000, adv_raw, sizeof(adv_raw));
        break;
    }
    nano_bcn_load_data_to_ram();
    nano_bcn_start_advertising();
    std::cout << "advertising ..." << std::endl;
    Sleep(15000);

    /*change advertising payload*/
    bcn_adv_data_reset();
    nano_bcn_chip_reset();

    /* advertising set #1 */
    bcn_adv_tx_set(ADV_SET_1, 1000, ADV_CH_37_38_39, ADV_MODE_CONTINUOUS);
    bdaddr[0] = 0x10;
    bcn_adv_address_set(ADV_SET_1, ADDR_PUBLIC, bdaddr, 60, 0);
    adv_raw2[0] = 11;
    bcn_adv_data_add_predefined_data(ADV_SET_1, adv_raw2, sizeof(adv_raw2), 0);
    bcn_adv_data_add_adv_count(ADV_SET_1, 4, 0, 0);

    nano_bcn_load_data_to_ram();
    nano_bcn_start_advertising();
    std::cout << "exit" << std::endl;
    return 0;
}