/**
 ****************************************************************************************
 *
 * @file nano_bcn_dev.h
 *
 * @brief Nano beacon dev header file
 *
 * Copyright (C) Inplay Technologies Inc. 2018-2020
 *
 ****************************************************************************************
 */
#ifndef NANO_BCN_DEV_H
#define NANO_BCN_DEV_H

#include <stdint.h>
#include "nano_bcn_rgn2.h"

#define ON_CHIP_MEASUREMENT_ENABLE 1

typedef enum {
	BCN_GPIO0 = 0,
	BCN_GPIO1,
	BCN_GPIO2,
	BCN_GPIO3,
	BCN_GPIO4,
	BCN_GPIO5,
	BCN_GPIO6,
	BCN_GPIO7,
}bcn_gpio_t;

typedef enum {
	BCN_GPIO_DIGITAL_DISABLE = 0,
	BCN_GPIO_INPUT,
	BCN_GPIO_OUTPUT_LOW,
	BCN_GPIO_OUTPUT_HIGH,
}bcn_gpio_dir_t;

typedef enum {
	BCN_GPIO_PULL_DISABLE = 0,
	BCN_GPIO_PULL_UP,
	BCN_GPIO_PULL_DOWN,
}bcn_gpio_pull_t;

typedef enum {
	GPIO_TRIGGER_HIGH = 0,
	GPIO_TRIGGER_LOW,
	GPIO_TRIGGER_RISING_EDGE,
	GPIO_TRIGGER_FALLING_EDGE,
}gpio_trigger_t;

typedef enum {
	NONCE_SALT_STATIC_RANDOM = 0, /*unchange after cold boot*/
	NONCE_SALT_RANDOM,
	NONCE_SALT_PREDEFINED,
}bcn_nonce_salt_t;

typedef enum {
	NONCE_CNT_SECOND_CNT = 0, /*1s count */
	NONCE_CNT_100MS_CNT, /*0.1s count */
	NONCE_CNT_ADV_CNT,
	NONCE_CNT_PREDEFINED,
	NONCE_CNT_STATIC_RANDOM,
	NONCE_CNT_RANDOM = 6
}bcn_nonce_cnt_t;

/*
 * APIs
 ****************************************************************************************
 */
#if defined(__cplusplus)
extern "C" {                // Make sure we have C-declarations in C++ programs
#endif

void bcn_rgn1_set_region23_from_ram(void);
void bcn_xo_settings(uint8_t capacitor, uint8_t stable_time, uint8_t strength);
void bcn_tx_power_set(int8_t tx_power, uint16_t efuse05);
void bcn_gpio_config(bcn_gpio_t gpio, bcn_gpio_dir_t dir, bcn_gpio_pull_t pull, trig_type_t point_of_time);
void bcn_timer1_enable(void);
void bcn_crypto_config(bcn_nonce_salt_t salt, bcn_nonce_cnt_t cnt);

void bcn_on_chip_measurement_en(uint8_t vcc_en, uint8_t temp_en);
#if ON_CHIP_MEASUREMENT_ENABLE
void bcn_on_chip_measurement_temp_unit_mapping(uint16_t efuse09_val, float unit_lsb);
void bcn_on_chip_measurement_vcc_unit_mapping(uint16_t efuse06_val, uint16_t efuse07_val, uint16_t efuse08_val, float unit_lsb);
#endif

#if defined(__cplusplus)
}     /* Make sure we have C-declarations in C++ programs */
#endif
#endif	// NANO_BCN_DEV_H
